# The list of packages we'll require. Consider it our shiny toolbox.
required_packages <- c("shiny", "shinythemes", "plotly","FactoMineR", "factoextra", "imputeTS", "readxl", "ggplot2", "ggpubr", "readr", "dplyr", "tidyr", "gridExtra", "DT", "janitor")

# If any package is missing, let's install it on-the-fly.
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
  # Load the package into our R session.
  library(pkg, character.only = TRUE)
}

# Crafting the user interface for our app.
ui = navbarPage(
  
  # Naming our app. Make sure to pick a cool name, or else it won't work.
  title = "SCP Viz 1.0.0",
  
  theme = shinytheme("flatly"),
  
  # Laying out the main structure: a sidebar for inputs and a main panel for outputs.
  tabPanel("Main",
           sidebarLayout(
             
             # The sidebar: where users tell us what they want. They are SO picky. 
             sidebarPanel(
               # A space for users to provide their own CSV.
               fileInput("data_upload", "Upload CSV file", accept = NULL),
               # An option to address those pesky missing values.
               checkboxInput("impute_zeros", "Would you like to impute N/A's?", value = FALSE),
               # What do we do if there are missing values? Here are some methods.
               conditionalPanel(
                 condition = "input.impute_zeros == true",
                 radioButtons("imputation_method", "Choose imputation method:",
                              choices = c("Replace with zeros" = "zeros",
                                          "Background Noise" = "background_noise")),
                 selected = "zeros"),
               # If they chose 'background noise', let them adjust the level.
               conditionalPanel(
                 condition = "input.imputation_method == 'background_noise'",
                 sliderInput("background_noise_level", "Choose Background Noise Level:", min = 0, max = 10^4, value = 0)
               ),
               # Getting specifics for sample columns and proteins.
               textInput("sample_keyword", "Text used for quan columns, e.g. Abundance, Intensity, PG.Quantity", value = ""),
               selectInput("protein_col", "Header for Protein ID Column", choices = NULL),
               textInput("protein", "Enter Protein ID", value = ""),
               # Specifying the number of conditions.
               numericInput("num_conditions", "Number of Conditions (For sub-conditions within a primary condition, separate with the word 'or')", value = 1, min = 1),
               uiOutput("conditions_input"),
               # A big ol' button to execute the user's wishes.
               submitButton("Unleash the Analysis"),
             ),
             
             # The main panel: our space to deliver results. Don't mess this up.
             mainPanel(
               # Organizing our outputs with tabs for clarity.
               tabsetPanel(
                 # Each tab is a different view or analysis of the data.
                 # Simple table to summarize the data.
                 tabPanel("Summary Table",
                          radioButtons("summary_choice", "Choose Summary Type:",
                                       choices = c("Group" = "group", "Individual" = "individual")),
                          DTOutput("summary_table")),
                 # Just showcasing the columns they selected.
                 tabPanel("Selected Columns", DTOutput("selected_columns")),
                 # Who doesn't love a good PCA plot?
                 tabPanel("PCA Plot", 
                          radioButtons("log2_choice_pca", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("pca_plot"),
                          # If they found something interesting, let them take the data home with them. 
                          uiOutput("download_button_ui")),
                 # Classic bar plot for comparisons.
                 tabPanel("Bar Plot", 
                          radioButtons("log2_choice_bar", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("bar_plot")),
                 # Box plots provide a deeper look into data distribution.
                 tabPanel("Box Plot", 
                          radioButtons("log2_choice_box", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("box_plot")),
                 # Histograms for frequency distributions.
                 tabPanel("Histogram", 
                          radioButtons("log2_choice_hist", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          sliderInput("bin_height", "Choose Number of Bins:", min = 5, max = 250, value = 50),
                          plotlyOutput("hist_plot")),
                 # Density plots for a smooth view of distributions.
                 tabPanel("Density Plot", 
                          radioButtons("log2_choice_dens", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("density_plot")),
                 # And violins, because they're elegant (and useful!). Unlike viola plots, ew. 
                 tabPanel("Violin Plot",
                          radioButtons("log2_choice_violin", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")), 
                          plotlyOutput("violin_plot"))
               )
             )
           )
  )
)

# The 'server' is the backbone of our shiny app. It's where the magic happens!
server = function(input, output, session) {
  # Adjusting settings to allow large data uploads.
  options(shiny.maxRequestSize = Inf)
  
  # Dynamically reading the uploaded data and cleaning the column names.
  data <- reactive({
    # Ensure the data upload input is present.
    req(input$data_upload)
    filepath <- input$data_upload$datapath
    fileext <- tools::file_ext(filepath)
    
    # Read the uploaded file depending on its extension.
    if (fileext == "csv") {
      file <- read_csv(filepath)
    } else if (fileext == "tsv") {
      file <- read_delim(filepath, delim = '\t')# Read TSV properly
      write_csv(file, "newfile.csv")
      file <- read_csv("newfile.csv")
    } else if (fileext %in% c("xlsx", "xls")) {
      file <- read_excel(filepath)
      # Convert the Excel file to a CSV for processing
      write_csv(file, "newfile.csv")
      file <- read_csv("newfile.csv")
    } else {
      stop("Invalid file type") # Handle unsupported formats.
    }
    
    # Clean up column names for better usability.
    janitor::clean_names(file)
  })
  
  # Once we upload the data, dynamically update the dropdown menu in the UI.
  observeEvent(input$data_upload, {
    file <- data() %>%
      janitor::clean_names()
    updateSelectInput(session, "protein_col", choices = names(file))
  })
  
  # Select the appropriate columns from the uploaded CSV.
  selected_columns <- reactive({
    req(input$sample_keyword, input$data_upload)
    selected <- grepl(input$sample_keyword, names(data()), ignore.case = TRUE)
    data.frame(column_name = names(data())[selected])
  })
  
  # Display the selected columns in the UI.
  output$selected_columns <- renderTable({
    selected_columns()
  })
  
  # Organize the data to get it ready for visualization.
  organized_data <- reactive({
    req(input$protein_col)
    data() %>% 
      select(input$protein_col, contains(input$sample_keyword))
  })
  
  # For some visuals, we need the data in a dataframe format.
  df <- reactive({
    data.frame(organized_data())
  })
  
  # Convert our data to a 'long' format which is preferable for certain visualizations.
  df_long <- reactive({
    selected_col <- input$protein_col
    print(paste("Selected column:", selected_col))
    long_data <- df() %>%
      pivot_longer(cols = -all_of(selected_col), names_to = "Samples", values_to = "Intensity")
    
    # Check and handle missing data based on user's preference.
    if (input$impute_zeros) { 
      if (input$imputation_method == "zeros") {
        long_data <- long_data %>%
          mutate(Intensity = ifelse(is.na(Intensity), 0, Intensity))
      } else if (input$imputation_method == "background_noise") {
        long_data <- long_data %>%
          mutate(Intensity = ifelse(is.na(Intensity), input$background_noise_level, Intensity))
      }
    }
    
    long_data
  })
  
  # Filtering the long dataframe based on the protein selection by the user.
  df_filtered <- reactive({
    req(input$protein)
    col_name <- input$protein_col
    df_long() %>%
      filter((!!as.name(col_name)) == input$protein)
  })
  
  # Render input fields dynamically based on the number of conditions specified by the user.
  output$conditions_input <- renderUI({
    lapply(1:input$num_conditions, function(i) {
      textInput(inputId = paste0("condition_", i), label = paste0("Condition ", i), value = "")
    })
  })
  
  # This function identifies the sample type based on user-defined conditions.
  get_sample_type <- function(Samples, num_conditions, input) {
    conditions <- sapply(1:num_conditions, function(i) {
      
      # Convert condition input to lowercase and then split by "or", 
      # and remove any leading/trailing spaces
      condition_terms <- trimws(unlist(strsplit(tolower(input[[paste0("condition_", i)]]), split = "or", fixed = TRUE)))
      
      # Check if any of the terms match the Samples string
      any(sapply(condition_terms, function(x) grepl(paste0(x), Samples, ignore.case = TRUE)))
    })
    condition_names <- paste0("condition_", seq_along(conditions))
    matched_condition <- match(TRUE, conditions, nomatch = NA)
    
    if (!is.na(matched_condition)) {
      return(input[[paste0("condition_", matched_condition)]]) # If a match is found, return the matched condition name.
    }
    return(NA) # If no match is found, return NA.
  }
  
  # Extend the filtered data to include color assignments based on sample group.
  df_filtered_with_color <- reactive({
    df_filtered() %>%
      rowwise() %>%
      mutate(Group = get_sample_type(Samples, input$num_conditions, input)) %>%
      ungroup()
  })
  
  # Reactive function to retrieve the unique condition names, omitting any NA values.
  condition_names <- reactive({
    unique(na.omit(df_filtered_with_color()$Group))
  })
  
  # Generate a summary table to give an overview of the data based on the user's choice of grouping.
  output$summary_table <- renderDT({
    if (input$summary_choice == "group") {
      summary_data <- df_filtered_with_color() %>%
        group_by(Group) %>%
        summarise(
          min = min(Intensity, na.rm = TRUE),
          max = max(Intensity, na.rm = TRUE),
          median = round(median(Intensity, na.rm = TRUE), 2),
          mean = round(mean(Intensity, na.rm = TRUE), 2),
          SD = round(sd(Intensity, na.rm = TRUE), 2),
          n_total = length(Intensity),
          n_missing = sum(is.na(Intensity)),
          pct_missing = round(sum(is.na(Intensity))/length(Intensity), 3),
          n_values = sum(!is.na(Intensity))
        )
    } else { # For individual summaries.
      summary_data <- df_filtered() %>%
        group_by(Samples) %>%
        summarise(
          Abundance = sum(Intensity, na.rm = TRUE) # Sum up the Intensity for each sample as an example.
        )
    }
    datatable(summary_data) # Display the constructed summary data in a table format.
  })
  
  # Display the columns selected by the user in a table for confirmation.
  output$selected_columns <- renderDT({
    selected_columns()
  })
  
  #Now lets make the PCA plot
  # Create a reactive function for data transformation (wide format) and grouping.
  # The data is converted from long to wide format and potentially undergoes log2 transformation.
  df_wide_with_color <- reactive({
    # Convert from long to wide format based on user's selected protein column.
    df_wide <- df_long() %>%
      group_by(Samples, !!sym(input$protein_col)) %>%
      slice(1) %>%
      ungroup() %>%
      filter(input$protein_col != "sp") %>%
      pivot_wider(names_from = !!sym(input$protein_col), values_from = Intensity) %>%
      select_if(~ !any(is.na(.)))
    
    # Apply log2 conversion if user chooses to.
    if (input$log2_choice_pca == "log2") {
      df_wide <- df_wide %>%
        mutate(across(-Samples, ~log2(. + 1)))
    }
    
    # Add the Group column to identify sample type.
    df_wide %>%
      rowwise() %>%
      mutate(Group = get_sample_type(Samples, input$num_conditions, input))
  })
  
  # Create a reactive function to compute the PCA results from the transformed data.
  pca_data <- reactive({
    # Remove the Samples and Group columns for PCA computation.
    df_for_pca <- df_wide_with_color() %>%
      select(-Samples, -Group)
    
    # Compute PCA on the data.
    pca_res <- PCA(df_for_pca, graph = FALSE, ncp = 2)
    
    # Construct a dataframe to store the PCA results along with the Group information.
    df_pca <- data.frame(Dim1 = pca_res$ind$coord[, 1],
                         Dim2 = pca_res$ind$coord[, 2],
                         Group = df_wide_with_color()$Group)
    df_pca
  })
  
  # Render a plotly PCA plot for the user using the pca_data.
  output$pca_plot <- renderPlotly({
    req(pca_data())
    pca_df <- pca_data()
    
    # Generate the PCA plot with ggplot2.
    pca_plot <- ggplot(pca_df, aes(x = Dim1, y = Dim2, color = Group)) +
      geom_point(alpha = 0.7, size = 3) +
      theme_classic(base_size = 20) +
      labs(title = "PCA plot", x = "PC1", y = "PC2")
    
    # Convert ggplot object to plotly object for interactivity.
    ggplotly(pca_plot, source = "pcaPlot")
  })
  
  #Let's make the PCA plot interactive.
  # Initialize a variable to store points selected interactively in the PCA plot.
  selected_points <- reactiveVal(data.frame())
  
  # Observe any points selected by the user in the PCA plot and update the selected_points variable.
  observe({
    selected_data <- event_data("plotly_selected", source = "pcaPlot")
    
    # If points are selected
    if (!is.null(selected_data)) {
      selected_rows <- selected_data$pointNumber + 1
      selected_points(df_wide_with_color()[selected_rows,])
    } else {
      # If no points are selected
      selected_points(data.frame()) 
    }
  })
  
  output$download_button_ui <- renderUI({
    if (!is.null(selected_points()) && nrow(selected_points()) > 0) {
      downloadButton("downloadCSV", "Download Selected Points")
    } else {
      NULL
    }
  })
  
  # Provide the user with a way to download the selected points from the PCA plot as a CSV file.
  output$downloadCSV <- downloadHandler(
    filename = function() "selected_points.csv",
    content = function(file) {
      write_csv(selected_points(), file)
    }
  )
  
  # Render a bar plot based on user data and preferences.
  output$bar_plot <- renderPlotly({
    
    # Check if log2 transformation is selected for the bar plot, if yes, then apply the transformation.
    if (input$log2_choice_bar == "log2") {
      plot_data <- df_filtered_with_color() %>%
        mutate(Intensity = log2(Intensity + 1)) # Add 1 to avoid log2(0)
    } else {
      plot_data <- df_filtered_with_color()
    }
    
    # Generate a bar plot using ggplot2.
    bar_plotly <- ggplot(plot_data, aes(x = Samples, y = Intensity, fill = Group)) +
      geom_bar(stat = "identity", position = "dodge") +
      facet_grid(cols = vars(Group)) +
      theme_classic(base_size = 12) +
      theme(axis.text.x = element_blank()) +
      labs(y = paste("Intensity")) 
    
    # Convert the ggplot object to a Plotly object
    interactive_bar_plot <- ggplotly(bar_plotly)
    
    # Print the Plotly object to render it interactively
    print(interactive_bar_plot)
  })
  
  # Render a box plot for data visualization.
  output$box_plot <- renderPlot({
    
    # Apply log2 transformation if selected for the box plot.
    if (input$log2_choice_box == "log2") {
      plot_data <- df_filtered_with_color() %>%
        mutate(Intensity = log2(Intensity + 1)) # Add 1 to avoid log2(0)
    } else {
      plot_data <- df_filtered_with_color()
    }
    
    # Define comparisons for the statistical test.
    my_comparisons <- list(
      c(condition_names()[1], condition_names()[2]) # Adjust these to match the actual values in your Group variable
    )
    
    # Generate a box plot using ggplot2.
    box_plot <- ggplot(plot_data, aes(x = Group, y = Intensity, fill = Group)) +
      geom_boxplot(width = 0.5) +
      geom_jitter(width = 0.2) +
      theme_classic(base_size = 14) +
      labs(x = "Group", y = paste("Intensity", unique(df_filtered()$protein_id))) +
      ggpubr::stat_compare_means(
        comparisons = my_comparisons,
        method = "t.test",
      )
    
    # Display the box plot.
    print(box_plot)
  })
  
  # Render an interactive histogram for data visualization.
  output$hist_plot <- renderPlotly ({
    # Set the bin height based on user input.
    bin_height <- input$bin_height
    
    # Apply log2 transformation if selected for the histogram.
    if (input$log2_choice_hist == "log2") {
      plot_data <- df_filtered_with_color() %>%
        mutate(Intensity = log2(Intensity + 1)) # Add 1 to avoid log2(0)
    } else {
      plot_data <- df_filtered_with_color()
    }
    
    # Generate a histogram using ggplot2.
    hist_plotly <- ggplot(plot_data, aes(x = Intensity, fill = Group)) +
      geom_histogram(bins = bin_height, color = "black") + # Use both binwidth and bins
      theme_classic(base_size = 14) +
      labs(x = "Intensity", y = "Frequency")
    
    # Convert the ggplot object to a Plotly object for interactivity.
    interactive_hist_plot <- ggplotly(hist_plotly)
    
    # Print the Plotly object to render it interactively
    print(interactive_hist_plot)
  })
  
  # Render the density plot
  output$density_plot <- renderPlot({
    
    # Apply log2 transformation if selected for the density plot.
    if (input$log2_choice_dens == "log2") {
      plot_data <- df_filtered_with_color() %>%
        mutate(Intensity = log2(Intensity + 1)) # Add 1 to avoid log2(0)
    } else {
      plot_data <- df_filtered_with_color()
    }
    
    # Generate a density plot using ggplot2.
    density_plot <- ggplot(plot_data, aes(x = Intensity, fill = Group)) +
      geom_density(alpha = 0.5) + # You can change the alpha to control the transparency of the plot
      theme_classic(base_size = 16) +
      labs(x = "Intensity", y = "Density")
    
    # Display the density plot.
    print(density_plot)
  })
  
  # Render an interactive violin plot.
  output$violin_plot <- renderPlotly({
    # Ensure that the filtered data with the color is available before generating the plot.
    req(df_filtered_with_color())
    
    # Apply log2 transformation if selected for the violin plot.
    if (input$log2_choice_violin == "log2") {
      plot_data <- df_filtered_with_color() %>%
        mutate(Intensity = log2(Intensity + 1)) # Add 1 to avoid log2(0)
    } else {
      plot_data <- df_filtered_with_color()
    }
    
    # Function to compute mean and standard deviation for data points.
    mean_sdl <- function(x, mult = 1) {
      mean <- mean(x, na.rm = TRUE)
      sdl <- sd(x, na.rm = TRUE) * mult
      data.frame(y = mean, ymin = mean - sdl, ymax = mean + sdl)
    }
    
    # Generate a violin plot using ggplot2.
    p_violin <- ggplot(plot_data, aes(x = Group, y = Intensity, fill = Group)) +
      geom_violin() +
      stat_summary(fun.data = mean_sdl, fun.args = list(mult = 1),
                   geom = "pointrange", color = "black",
                   shape = 18, size = 0.75,
                   position = position_dodge(width = 0.9)) +
      labs(title = "Violin Plot",
           x = "Conditions",
           y = ifelse(input$log2_choice == "log2", "Log2 Intensity", "Intensity")) +
      theme_minimal() +
      theme(
        text = element_text(size = 14),                # Overall text size
        axis.title = element_text(size = 14),          # Axis title size
        axis.text = element_text(size = 14),           # Axis text (ticks) size
        plot.title = element_text(size = 14, hjust = 0.5) # Plot title size
      )
    
    # Convert the ggplot object to a Plotly object
    interactive_violin_plot <- ggplotly(p_violin)
    
    # Print the Plotly object to render it interactively
    print(interactive_violin_plot)
  })
}

# Run the app ----

shinyApp(ui = ui, server = server)


